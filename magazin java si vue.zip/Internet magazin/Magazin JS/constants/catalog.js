const CATALOG = [
    {
        id: 'el1',
        name: 'Arnold',
        img: 'img/1.jpg',
        price: 50,
    },
    {
        id: 'el2',
        name: 'Arnold',
        img: 'img/2.jpg',
        price: 99,
    },
    {
        id: 'el3',
        name: 'Arnold',
        img: 'img/3.jpg',
        price: 200,
    },
    {
        id: 'el4',
        name: 'Arnold',
        img: 'img/4.jpg',
        price: 120,
    },
    {
        id: 'el5',
        name: 'Arnold',
        img: 'img/5.jpg',
        price: 550,
    },
    {
        id: 'el6',
        name: 'Arnold',
        img: 'img/6.jpg',
        price: 40,
    },
    {
        id: 'el7',
        name: 'Arnold',
        img: 'img/7.jpg',
        price: 25,
    },
    {
        id: 'el8',
        name: 'Arnold',
        img: 'img/8.jpg',
        price: 249,
    },
    {
        id: 'el9',
        name: 'Arnold',
        img: 'img/9.jpg',
        price: 80,
    },

];